require "/scripts/vore/npcvore.lua"

legs = "avalilegs"

fulllegs = "avalilegsbelly"
